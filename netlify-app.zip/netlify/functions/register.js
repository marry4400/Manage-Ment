// নাম, ব্র্যান্ড ও আইপি আপনার লগ-এ পাঠায়। LOG_WEBHOOK_URL (Netlify env) বসালে চালু হবে।
exports.handler = async (event) => {
  try {
    const b = JSON.parse(event.body || '{}');
    const ip = event.headers['x-nf-client-connection-ip'] || event.headers['x-forwarded-for'] || '';
    if (process.env.LOG_WEBHOOK_URL) await fetch(process.env.LOG_WEBHOOK_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: b.name, brand: b.brand, ip, at: new Date().toISOString() }) });
  } catch (e) {}
  return { statusCode: 200, body: 'ok' };
};
