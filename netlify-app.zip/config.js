// Google Cloud থেকে পাওয়া OAuth Client ID এখানে বসান
window.APP_CONFIG={clientId:'398145690525-tnvnuprvicb7p1ltkod6102gvg02gvq9.apps.googleusercontent.com'};
